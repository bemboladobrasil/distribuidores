# Bem Bolado · Diretório de Distribuidores

Este repositório publica o `index.html` via GitHub Pages.

## Publicar
1. Crie um repositório público no GitHub (ex.: `bem-bolado-distribuidores`).
2. Envie este `index.html` para a raiz do repositório (pasta principal).
3. Vá em **Settings → Pages → Build and deployment → Source: Deploy from a branch**.
4. Selecione **Branch: main** e **Folder: /** e clique **Save**.
5. O site vai ao ar em alguns minutos em: `https://SEU_USUARIO.github.io/bem-bolado-distribuidores/`

Para atualizar, substitua o `index.html` e faça novo commit.
